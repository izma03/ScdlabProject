/*
 *
 */
public interface InterfaceA {
    public void x();
}

interface InterfaceB
{
    public void back();
}
