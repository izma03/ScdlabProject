/**
 *
 * @author laiba
 */
public class Main {
    public static void main(String [] arg){
        
        WelcomePage w = new WelcomePage();
        w.setVisible(true);
        w.setLocationRelativeTo(null);
    }
}
