
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

/*
 * 
 */
public class DatabaseConnection {
    private static DatabaseConnection connect;
    String[] data;
    private DatabaseConnection(){
        data=new String[10];
    }
    public static DatabaseConnection connectionObject(){
        if(connect==null)
        {
            connect=new DatabaseConnection();
        }
        
        return connect;
    }
    
    Connection con ;
    public Connection connectDB(){
        try{  
            
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");  
            //here sonoo is database name, root is username and password 
            
            try
            {
                con = DriverManager.getConnection("jdbc:sqlserver://DESKTOP-KNEMPEF\\SQLEXPRESS;databaseName=BusTicketReservationProject;integratedSecurity=true");
                
                System.out.println("connected to db");
//              Statement stmt=con.createStatement();
//              stmt.executeUpdate("INSERT into login VALUES ('izma02','12345')");
//              ResultSet rs=stmt.executeQuery("select * from login");
//              while(rs.nsext())
//              System.out.println(rs.getString(1)+"  "+rs.getString(2));  
    }
            catch(Exception e)
            {
                System.out.println(e);
            }
} 
        catch(Exception e)
        { 
            System.out.println(e);
        }  
        
        return con;
    }
   
    public String[] retrievedata(String uname )
    {
         
        try{
           
            Statement stmt=con.createStatement();
            ResultSet rs=stmt.executeQuery("exec Procedure4 '"+uname+"'");
            
            int i=0;
            while(rs.next()){
              String z=("          "+rs.getString(1)+"\t"+rs.getString(2)+"\t"+rs.getString(3)+"\t          "+rs.getString(4)+"\t    "+rs.getString(5)); 
              data[i]=z;
                i++;
            }
        }
        catch(Exception e){
            
        }
        return data;
    }
    
    
}
